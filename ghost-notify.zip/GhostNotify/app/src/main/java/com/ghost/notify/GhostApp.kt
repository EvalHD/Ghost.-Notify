package com.ghost.notify

import android.app.Application

class GhostApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        try {
            Notifier.ensureChannels(this)
            Cleanup.schedule(this)
        } catch (e: Exception) {
        }
    }
}
