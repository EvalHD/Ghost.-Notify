package com.ghost.notify

import android.app.PendingIntent

enum class AppMode(val label: String, val desc: String) {
    ALWAYS("Immer anzeigen", "Bleibt komplett unverändert, Ghost Notify fasst nichts an."),
    AUTO("Automatisch", "Wichtiges bleibt sichtbar, Normales wird gesammelt, Spam verschwindet."),
    ONLY_IMPORTANT("Nur Wichtiges", "Nur das Allerwichtigste bleibt sichtbar, der Rest geht still in die Ablage."),
    BUNDLE("Sammeln", "Alles landet gesammelt in einer einzigen Zusammenfassung."),
    BLOCK("Blockieren", "Nichts wird angezeigt, alles geht direkt in die Ablage.")
}

enum class Level { IMPORTANT, NORMAL, SPAM }

/** Was mit einer Benachrichtigung passiert ist. */
enum class Disp { SHOWN, BUNDLED, FILTERED, EXPIRED, SPAM }

enum class TapMode(val label: String) { OFF("Aus"), MAIL("Nur E-Mail"), ALL("Alle") }

data class Item(
    val id: Long,
    val key: String,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val big: String,
    val category: String,
    val time: Long,
    val level: Level,
    val disp: Disp,
    val seen: Boolean
)

data class Rule(val id: Long, val pkg: String, val pattern: String, val action: Level)

data class Parsed(
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val body: String,
    val category: String,
    val isGroup: Boolean,
    val time: Long,
    val pending: PendingIntent?
)
