package com.ghost.notify

object Classifier {

    data class Result(val level: Level, val byRule: Boolean, val score: Int)

    private val messengers = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "org.thoughtcrime.securesms",
        "com.google.android.apps.messaging", "com.samsung.android.messaging", "ch.threema.app",
        "com.facebook.orca", "com.discord", "com.microsoft.teams", "com.Slack", "com.slack"
    )

    private fun re(words: List<String>, whole: Boolean): Regex {
        val alt = words.joinToString("|") { Regex.escape(it) }
        val tail = if (whole) "(?![\\p{L}\\p{N}])" else ""
        return Regex("(?<![\\p{L}\\p{N}])(?:" + alt + ")" + tail, RegexOption.IGNORE_CASE)
    }

    private val importantWord = re(listOf("tan", "pin", "otp", "code", "login"), true)
    private val importantPrefix = re(
        listOf(
            "dringend", "wichtig", "sofort", "verifizier", "bestätigungs", "sicherheits", "passwort",
            "einmalpasswort", "einmalkennwort", "unbefugt", "verdächtig", "fehlgeschlagen", "abgebucht",
            "überweisung", "mahnung", "fällig", "paket", "zugestellt", "zustell", "abholbereit", "abholen",
            "termin", "erinnerung", "anruf", "verpasst", "urgent", "verification", "security", "delivery",
            "delivered", "appointment", "missed", "alarm", "warnung", "notfall"
        ), false
    )
    private val spamWord = re(listOf("sale", "deal", "promo", "coupon", "bonus", "gratis"), true)
    private val spamPrefix = re(
        listOf(
            "angebot", "rabatt", "gutschein", "kostenlos", "aktion", "newsletter", "werbung", "jetzt sichern",
            "nur heute", "tarif", "vertrag", "verlänger", "upgrade", "prämie", "gewinn", "exklusiv", "sparen",
            "entdecke", "empfehlung", "umfrage", "bewerte", "feedback", "wir vermissen", "jetzt wechseln",
            "datenvolumen", "flatrate", "cashback", "treuepunkte", "black friday", "blitz"
        ), false
    )
    private val percent = Regex("\\d+\\s?%")

    private fun hits(r: Regex, hay: String): Int = r.findAll(hay).map { it.value.lowercase() }.distinct().count()

    fun classify(p: Parsed, rules: List<Rule>, strict: Boolean): Result {
        for (r in rules) {
            if (r.pkg.isNotEmpty() && r.pkg != p.pkg) continue
            val pat = r.pattern
            if (pat.isBlank()) continue
            if (p.title.contains(pat, true) || p.text.contains(pat, true) || p.body.contains(pat, true)) {
                return Result(r.action, true, if (r.action == Level.SPAM) -99 else 99)
            }
        }

        val hay = (p.title + " " + p.text + " " + p.body).lowercase()
        var s = 0
        s += when (p.category) {
            "msg" -> 3
            "call", "alarm", "reminder", "event", "navigation" -> 4
            "email" -> 1
            "promo" -> -4
            "social", "recommendation" -> -2
            else -> 0
        }
        if (p.pkg in messengers) s += 3
        if (p.isGroup) s -= 3
        s += minOf(hits(importantWord, hay) + hits(importantPrefix, hay), 2) * 2
        s -= minOf(hits(spamWord, hay) + hits(spamPrefix, hay), 2) * 3
        if (percent.containsMatchIn(hay)) s -= 1

        val threshold = if (strict) 4 else 2
        val level = when {
            s >= threshold -> Level.IMPORTANT
            s <= -2 -> Level.SPAM
            else -> Level.NORMAL
        }
        return Result(level, false, s)
    }
}
