package com.ghost.notify

import android.content.ComponentName
import android.content.Context
import android.service.notification.NotificationListenerService

/** Verbindet den Benachrichtigungs-Dienst neu, falls Android ihn nach einem Update oder Absturz nicht mehr startet. */
object Rebind {
    fun ensure(ctx: Context) {
        try {
            if (isListenerEnabled(ctx) && GhostListener.instance == null) force(ctx)
        } catch (e: Exception) {
        }
    }

    fun force(ctx: Context) {
        NotificationListenerService.requestRebind(ComponentName(ctx, GhostListener::class.java))
    }
}
