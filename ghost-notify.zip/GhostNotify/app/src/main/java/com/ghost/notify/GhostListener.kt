package com.ghost.notify

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.NotificationListenerService.RankingMap
import android.service.notification.StatusBarNotification

class GhostListener : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: GhostListener? = null

        // Diese Kategorien fasst Ghost Notify nie an (Anrufe, Wecker, Navigation, laufende Dienste ...)
        private val never = setOf(
            "call", "alarm", "navigation", "transport", "progress", "service", "sys",
            "status", "err", "stopwatch", "workout", "location_sharing", "missed_call"
        )
    }

    override fun onListenerConnected() {
        instance = this
        Store.init(applicationContext)
        try {
            Notifier.ensureChannels(applicationContext)
            Cleanup.run(applicationContext)
        } catch (e: Exception) {
        }
    }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (e: Throwable) {
            // Lieber eine Benachrichtigung unverändert lassen als etwas zu verlieren
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification, rankingMap: RankingMap, reason: Int) {
        try {
            if (reason == REASON_CLICK || reason == REASON_CANCEL || reason == REASON_CANCEL_ALL) {
                Store.init(applicationContext)
                Store.db.markSeenByKey(sbn.key)
                Store.changed()
            }
        } catch (e: Throwable) {
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        val ctx = applicationContext
        Store.init(ctx)

        val pkg = sbn.packageName ?: return
        if (pkg == ctx.packageName) return
        val n = sbn.notification ?: return
        if (!sbn.isClearable) return

        val skipFlags = Notification.FLAG_GROUP_SUMMARY or Notification.FLAG_FOREGROUND_SERVICE or Notification.FLAG_ONGOING_EVENT
        if ((n.flags and skipFlags) != 0) return
        val cat = n.category
        if (cat != null && cat in never) return

        val mode = Store.prefs.mode(pkg)
        if (mode == AppMode.ALWAYS) return

        val p = Parser.parse(ctx, sbn)
        if (p.title.isBlank() && p.text.isBlank() && p.body.isBlank()) return

        // Doppelte (Updates derselben Nachricht) nicht erneut einsortieren
        val dup = Store.db.findRecent(pkg, p.title, p.text, System.currentTimeMillis() - 10 * 60_000L)
        if (dup != null) {
            if (dup.disp != Disp.SHOWN) cancelNotification(sbn.key)
            return
        }

        val res = Classifier.classify(p, Store.db.rules(), mode == AppMode.ONLY_IMPORTANT)
        val level = res.level

        val disp: Disp = when (mode) {
            AppMode.BLOCK -> if (level == Level.SPAM) Disp.SPAM else Disp.FILTERED
            AppMode.BUNDLE -> when {
                level == Level.SPAM -> Disp.SPAM
                level == Level.IMPORTANT && res.byRule -> Disp.SHOWN
                else -> Disp.BUNDLED
            }
            AppMode.ONLY_IMPORTANT -> when (level) {
                Level.IMPORTANT -> Disp.SHOWN
                Level.SPAM -> Disp.SPAM
                Level.NORMAL -> Disp.FILTERED
            }
            else -> when (level) {
                Level.IMPORTANT -> Disp.SHOWN
                Level.NORMAL -> Disp.BUNDLED
                Level.SPAM -> Disp.SPAM
            }
        }

        p.pending?.let { Store.cacheIntent(sbn.key, it) }

        val draft = Item(0, sbn.key, pkg, p.app, p.title, p.text, p.body, p.category, sbn.postTime, level, disp, false)
        val id = Store.db.insert(draft)
        val item = draft.copy(id = id)

        if (disp == Disp.SHOWN) {
            if (Notifier.shouldReplace(ctx, item)) {
                Notifier.postReplacement(ctx, item, n)
                cancelNotification(sbn.key)
            }
        } else {
            cancelNotification(sbn.key)
        }

        if (disp == Disp.BUNDLED) Notifier.updateDigest(ctx)
        Store.changed()
    }
}
