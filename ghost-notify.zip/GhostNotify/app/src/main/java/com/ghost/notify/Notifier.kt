package com.ghost.notify

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon

object Notifier {
    const val CH_IMPORTANT = "ghost_important"
    const val CH_DIGEST = "ghost_digest"
    const val DIGEST_ID = 1

    const val ACT_SPAM = "com.ghost.notify.SPAM"
    const val ACT_SEEN = "com.ghost.notify.SEEN"
    const val ACT_CLEAR = "com.ghost.notify.CLEAR_DIGEST"
    const val ACT_DIGEST_SEEN = "com.ghost.notify.DIGEST_SEEN"
    const val ACT_CLEAR_ALL = "com.ghost.notify.CLEAR_ALL"
    const val ACT_TOGGLE_PAUSE = "com.ghost.notify.TOGGLE_PAUSE"

    fun replId(id: Long): Int = 10000 + (id % 1000000L).toInt()

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val a = NotificationChannel(CH_IMPORTANT, "Wichtig", NotificationManager.IMPORTANCE_HIGH)
        a.description = "Wichtige Benachrichtigungen, die Ghost Notify für dich durchlässt"
        nm.createNotificationChannel(a)
        val b = NotificationChannel(CH_DIGEST, "Zusammenfassung", NotificationManager.IMPORTANCE_LOW)
        b.description = "Gesammelte, weniger wichtige Benachrichtigungen"
        nm.createNotificationChannel(b)
    }

    private fun openIntent(ctx: Context, id: Long, tab: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        if (id > 0) i.putExtra("open_id", id)
        i.putExtra("tab", tab)
        val code = if (id > 0) replId(id) else 2
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun receiverIntent(ctx: Context, action: String, id: Long): PendingIntent {
        val i = Intent(ctx, ActionReceiver::class.java)
        i.action = action
        i.putExtra("id", id)
        val code = (action.hashCode() xor replId(id)) and 0x7fffffff
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun actionIcon(ctx: Context): Icon = Icon.createWithResource(ctx, R.drawable.ic_stat_ghost)

    fun canPost(ctx: Context): Boolean = ctx.getSystemService(NotificationManager::class.java).areNotificationsEnabled()

    fun shouldReplace(ctx: Context, item: Item): Boolean {
        if (!canPost(ctx)) return false
        return when (Store.prefs.tapMode) {
            TapMode.OFF -> false
            TapMode.MAIL -> AppInfo.isMail(item.pkg, item.category)
            TapMode.ALL -> true
        }
    }

    /** Ersetzt eine Original-Benachrichtigung durch eine eigene, die beim Antippen die Zusammenfassung öffnet. */
    fun postReplacement(ctx: Context, item: Item, orig: Notification) {
        ensureChannels(ctx)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val b = Notification.Builder(ctx, CH_IMPORTANT)
            .setSmallIcon(R.drawable.ic_stat_ghost)
            .setContentTitle(item.title.ifBlank { item.app })
            .setContentText(item.text.ifBlank { item.big })
            .setSubText(item.app)
            .setWhen(item.time)
            .setShowWhen(true)
            .setAutoCancel(true)
            .setContentIntent(openIntent(ctx, item.id, 0))
            .setDeleteIntent(receiverIntent(ctx, ACT_SEEN, item.id))

        val bigText = if (item.big.isNotBlank()) item.big else item.text
        if (bigText.isNotBlank()) b.setStyle(Notification.BigTextStyle().bigText(bigText))

        try {
            val large = orig.getLargeIcon()
            if (large != null) b.setLargeIcon(large)
        } catch (e: Exception) {
        }

        try {
            orig.actions?.take(2)?.forEach { b.addAction(it) }
        } catch (e: Exception) {
        }

        b.addAction(
            Notification.Action.Builder(actionIcon(ctx), "Spam", receiverIntent(ctx, ACT_SPAM, item.id)).build()
        )
        nm.notify(replId(item.id), b.build())
    }

    fun cancelRepl(ctx: Context, id: Long) {
        ctx.getSystemService(NotificationManager::class.java).cancel(replId(id))
    }

    /** Sammel-Benachrichtigung für alles, was gebündelt wurde. */
    fun updateDigest(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!Store.prefs.digestOn || !nm.areNotificationsEnabled()) {
            nm.cancel(DIGEST_ID)
            return
        }
        val items = Store.db.list(listOf(Disp.BUNDLED), 100, onlyUnseen = true)
        if (items.isEmpty()) {
            nm.cancel(DIGEST_ID)
            return
        }
        ensureChannels(ctx)

        val inbox = Notification.InboxStyle()
        items.take(6).forEach { inbox.addLine(it.app + ": " + it.title.ifBlank { it.text }.take(60)) }
        inbox.setSummaryText(items.size.toString() + " gesammelt")

        val apps = items.map { it.app }.distinct()
        val appText = apps.take(4).joinToString(", ") + (if (apps.size > 4) " …" else "")

        val n = Notification.Builder(ctx, CH_DIGEST)
            .setSmallIcon(R.drawable.ic_stat_ghost)
            .setContentTitle(items.size.toString() + " Benachrichtigungen gesammelt")
            .setContentText(appText)
            .setStyle(inbox)
            .setOnlyAlertOnce(true)
            .setAutoCancel(true)
            .setWhen(items.first().time)
            .setContentIntent(openIntent(ctx, 0, 2))
            .setDeleteIntent(receiverIntent(ctx, ACT_DIGEST_SEEN, 0))
            .addAction(Notification.Action.Builder(actionIcon(ctx), "Leeren", receiverIntent(ctx, ACT_CLEAR, 0)).build())
            .build()
        nm.notify(DIGEST_ID, n)
    }
}
