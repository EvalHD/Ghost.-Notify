package com.ghost.notify

import android.app.NotificationManager
import android.content.Context
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

object Cleanup {
    fun run(ctx: Context) {
        Store.init(ctx)
        val now = System.currentTimeMillis()

        // 1) Alte Einträge endgültig löschen
        val keepMs = Store.prefs.keepDays * 24L * 3600_000L
        Store.db.deleteOlder(listOf(Disp.BUNDLED, Disp.FILTERED, Disp.EXPIRED, Disp.SPAM, Disp.SHOWN), now - keepMs)

        // 2) Ungesehene wichtige Benachrichtigungen aus der Leiste in die Ablage räumen
        val hours = Store.prefs.unseenHours
        val svc = GhostListener.instance
        if (hours > 0 && svc != null) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            Store.db.unseenShownBefore(now - hours * 3600_000L).forEach {
                Store.db.setDisp(it.id, Disp.EXPIRED)
                try { svc.cancelNotification(it.key) } catch (e: Exception) { }
                nm.cancel(Notifier.replId(it.id))
            }
        }

        Notifier.updateDigest(ctx)
        Store.changed()
    }

    fun schedule(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<CleanupWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("ghost_cleanup", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}

class CleanupWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        return try {
            Rebind.ensure(applicationContext)
            Cleanup.run(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
