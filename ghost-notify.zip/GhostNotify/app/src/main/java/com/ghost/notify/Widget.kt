package com.ghost.notify

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews

class GhostWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        try {
            appWidgetManager.updateAppWidget(appWidgetIds, Widget.build(context))
        } catch (e: Exception) {
        }
    }
}

object Widget {

    fun update(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, GhostWidget::class.java))
        if (ids.isEmpty()) return
        mgr.updateAppWidget(ids, build(ctx))
    }

    private fun open(ctx: Context, code: Int, id: Long, tab: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
        i.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        if (id > 0) i.putExtra("open_id", id)
        i.putExtra("tab", tab)
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun build(ctx: Context): RemoteViews {
        Store.init(ctx)
        val rv = RemoteViews(ctx.packageName, R.layout.widget_ghost)
        val paused = Store.prefs.paused
        val enabled = isListenerEnabled(ctx)

        if (paused) {
            rv.setTextViewText(R.id.w_status, "Pausiert")
            rv.setTextColor(R.id.w_status, Color.parseColor("#FFC857"))
        } else if (!enabled) {
            rv.setTextViewText(R.id.w_status, "Zugriff fehlt")
            rv.setTextColor(R.id.w_status, Color.parseColor("#FF6B8B"))
        } else {
            rv.setTextViewText(R.id.w_status, "Aktiv")
            rv.setTextColor(R.id.w_status, Color.parseColor("#5EEAD4"))
        }

        val dayAgo = System.currentTimeMillis() - 24L * 3600_000L
        rv.setTextViewText(R.id.w_n1, Store.db.list(listOf(Disp.SHOWN), 99, onlyUnseen = true).size.toString())
        rv.setTextViewText(R.id.w_n2, Store.db.list(listOf(Disp.BUNDLED), 99, onlyUnseen = true).size.toString())
        rv.setTextViewText(R.id.w_n3, Store.db.count(listOf(Disp.SPAM), dayAgo).toString())

        val rows = Store.db.list(listOf(Disp.SHOWN, Disp.BUNDLED), 3, onlyUnseen = true)
        val ids = intArrayOf(R.id.w_item1, R.id.w_item2, R.id.w_item3)
        for (i in 0 until 3) {
            if (i < rows.size) {
                val r = rows[i]
                rv.setTextViewText(ids[i], r.app + ": " + r.title.ifBlank { r.text })
                rv.setViewVisibility(ids[i], View.VISIBLE)
                rv.setOnClickPendingIntent(ids[i], open(ctx, 300 + i, r.id, 0))
            } else if (i == 0) {
                rv.setTextViewText(ids[i], "Alles ruhig.")
                rv.setViewVisibility(ids[i], View.VISIBLE)
            } else {
                rv.setViewVisibility(ids[i], View.GONE)
            }
        }

        rv.setTextViewText(R.id.w_btn_pause, if (paused) "Weiter" else "Pause")
        rv.setOnClickPendingIntent(R.id.w_header, open(ctx, 290, 0, 0))
        rv.setOnClickPendingIntent(R.id.w_btn_ablage, open(ctx, 291, 0, 2))
        rv.setOnClickPendingIntent(R.id.w_btn_clear, Notifier.receiverIntent(ctx, Notifier.ACT_CLEAR_ALL, 0))
        rv.setOnClickPendingIntent(R.id.w_btn_pause, Notifier.receiverIntent(ctx, Notifier.ACT_TOGGLE_PAUSE, 0))
        return rv
    }
}
