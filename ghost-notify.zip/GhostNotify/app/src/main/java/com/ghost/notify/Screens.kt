package com.ghost.notify

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- Gemeinsam ----------

@Composable
fun <T> ChoiceChips(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (label, value) ->
            FilterChip(
                selected = value == selected,
                onClick = { onSelect(value) },
                label = { Text(label) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Selected,
                    selectedLabelColor = Ghost
                )
            )
        }
    }
}

@Composable
fun SettingCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    GhostCard {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

// ---------- Apps ----------

data class AppEntry(val pkg: String, val label: String)

@Composable
fun ModeDialog(entry: AppEntry, current: AppMode, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(entry.pkg, 36.dp)
                Spacer(Modifier.width(12.dp))
                Text(entry.label, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        },
        text = {
            Column {
                AppMode.values().forEach { m ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                Store.prefs.setMode(entry.pkg, m)
                                Store.changed()
                                onDismiss()
                            }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = m == current, onClick = null)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(m.label, fontWeight = FontWeight.SemiBold, color = modeColor(m))
                            Text(m.desc, color = TextLo, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Schließen") } }
    )
}

@Composable
fun AppsScreen() {
    val ctx = LocalContext.current
    val tick by Store.tick.collectAsState()
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<AppEntry?>(null) }

    val base = remember { AppInfo.launchable(ctx).map { AppEntry(it.first, it.second) } }
    val known = remember(tick) { Store.db.knownPkgs() }
    val all = remember(base, known) {
        val have = base.map { it.pkg }.toSet()
        val extra = known.filter { it !in have && it != ctx.packageName }.map { AppEntry(it, AppInfo.label(ctx, it)) }
        (base + extra).sortedWith(
            compareBy<AppEntry>({ if (it.pkg in known) 0 else 1 }, { it.label.lowercase() })
        )
    }
    val list = remember(all, query) {
        if (query.isBlank()) all else all.filter { it.label.contains(query, true) }
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp)) {
            Text("Apps", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Tippe auf eine App und wähle, wie streng Ghost Notify sein soll.", color = TextLo, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("App suchen") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth()
            )
        }
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(list, key = { it.pkg }) { e ->
                val mode = remember(tick, e.pkg) { Store.prefs.mode(e.pkg) }
                val active = e.pkg in known
                GhostCard(Modifier.clip(RoundedCornerShape(16.dp)).clickable { editing = e }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        AppIcon(e.pkg, 40.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(e.label, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (active) "sendet Benachrichtigungen" else " ",
                                color = TextLo,
                                fontSize = 12.sp
                            )
                        }
                        Text(mode.label, color = modeColor(mode), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }

    editing?.let { e ->
        ModeDialog(e, Store.prefs.mode(e.pkg)) { editing = null }
    }
}

// ---------- Ablage ----------

@Composable
fun AblageScreen(onOpenItem: (Item) -> Unit) {
    val ctx = LocalContext.current
    val tick by Store.tick.collectAsState()
    var filter by remember { mutableIntStateOf(0) }
    var confirmClear by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        Store.db.markSeenDisps(listOf(Disp.BUNDLED, Disp.FILTERED, Disp.EXPIRED, Disp.SPAM))
        Notifier.updateDigest(ctx)
    }

    val disps = when (filter) {
        1 -> listOf(Disp.BUNDLED)
        2 -> listOf(Disp.FILTERED, Disp.EXPIRED)
        3 -> listOf(Disp.SPAM)
        else -> listOf(Disp.BUNDLED, Disp.FILTERED, Disp.EXPIRED, Disp.SPAM)
    }
    val rows = remember(tick, filter) { Store.db.list(disps, 300) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Ablage", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Alles, was Ghost Notify aus deiner Leiste genommen hat.", color = TextLo, fontSize = 13.sp)
                }
                TextButton(onClick = { confirmClear = true }) { Text("Leeren", color = Danger) }
            }
            Spacer(Modifier.height(8.dp))
            ChoiceChips(
                listOf("Alle" to 0, "Gesammelt" to 1, "Aussortiert" to 2, "Spam" to 3),
                filter
            ) { filter = it }
        }
        if (rows.isEmpty()) {
            Box(Modifier.padding(16.dp)) { EmptyCard("Hier ist nichts. Gut so.") }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(rows, key = { it.id }) { ItemCard(it) { onOpenItem(it) } }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = Surface1,
            title = { Text("Ablage leeren?") },
            text = { Text("Alle Einträge in der Ablage werden endgültig gelöscht.") },
            confirmButton = {
                TextButton(onClick = {
                    Actions.clearAblage(ctx)
                    confirmClear = false
                }) { Text("Leeren", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Abbrechen") } }
        )
    }
}

// ---------- Einstellungen ----------

@Composable
fun RuleDialog(onDismiss: () -> Unit) {
    var pattern by remember { mutableStateOf("") }
    var action by remember { mutableStateOf(Level.SPAM) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = { Text("Neue Regel") },
        text = {
            Column {
                Text("Wenn Titel oder Text dieses Wort enthält:", color = TextLo, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = pattern,
                    onValueChange = { pattern = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                ChoiceChips(listOf("Spam" to Level.SPAM, "Immer wichtig" to Level.IMPORTANT), action) { action = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (pattern.isNotBlank()) {
                    Store.db.addRule("", pattern.trim(), action)
                    Store.changed()
                }
                onDismiss()
            }) { Text("Speichern") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val tick by Store.tick.collectAsState()
    val prefs = Store.prefs

    val enabled = remember(tick) { isListenerEnabled(ctx) }
    val paused = remember(tick) { prefs.paused }
    val connected = remember(tick) { GhostListener.instance != null }
    val lastEvent = remember(tick) { prefs.lastEvent }
    val lastError = remember(tick) { prefs.lastError }
    val tap = remember(tick) { prefs.tapMode }
    val unseen = remember(tick) { prefs.unseenHours }
    val keep = remember(tick) { prefs.keepDays }
    val digest = remember(tick) { prefs.digestOn }
    val rules = remember(tick) { Store.db.rules() }
    var showRule by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Mehr", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }

        item {
            SettingCard("Pause") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ghost Notify pausieren (alles bleibt wie sonst)", Modifier.weight(1f))
                    Switch(
                        checked = paused,
                        onCheckedChange = {
                            prefs.paused = it
                            Store.changed()
                        }
                    )
                }
            }
        }

        item {
            SettingCard("Diagnose") {
                Text(
                    if (connected) "Dienst: verbunden" else "Dienst: nicht verbunden",
                    color = if (connected) Mint else Danger
                )
                Text(
                    "Letzte sortierte Meldung: " + (if (lastEvent == 0L) "noch keine" else timeAgo(lastEvent)),
                    color = TextLo,
                    fontSize = 13.sp
                )
                Text(
                    "Letzter Fehler: " + (if (lastError.isBlank()) "keiner" else lastError),
                    color = TextLo,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Nach einem App-Update trennt Android den Dienst manchmal. Dann hilft „Neu verbinden“. Wenn nicht: Zugriff in den Android-Einstellungen aus- und wieder einschalten.",
                    color = TextLo,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            try { Rebind.force(ctx) } catch (e: Exception) { }
                            Store.changed()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        modifier = Modifier.weight(1f)
                    ) { Text("Neu verbinden", maxLines = 1) }
                    OutlinedButton(
                        onClick = { prefs.lastError = ""; Store.changed() },
                        modifier = Modifier.weight(1f)
                    ) { Text("Fehler löschen", maxLines = 1) }
                }
            }
        }

        item {
            SettingCard("Zugriff & Akku") {
                Text(
                    if (enabled) "Benachrichtigungszugriff: an" else "Benachrichtigungszugriff: aus",
                    color = if (enabled) Mint else Danger
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Damit nichts durchrutscht: Stelle Ghost Notify in den Akku-Einstellungen auf „Nicht eingeschränkt“ und nimm es aus dem Energiesparen für Apps im Hintergrund.",
                    color = TextLo,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { launchSafe(ctx, Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
                        modifier = Modifier.weight(1f)
                    ) { Text("Zugriff", maxLines = 1) }
                    OutlinedButton(
                        onClick = {
                            launchSafe(
                                ctx,
                                Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                            )
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("App-Info", maxLines = 1) }
                }
            }
        }

        item {
            SettingCard("Zusammenfassung beim Antippen") {
                Text(
                    "Bei Apps, die nicht auf „Immer anzeigen“ stehen, ersetzt Ghost Notify wichtige Meldungen durch eine eigene. Antippen öffnet die Mini-Zusammenfassung. Antwort-Knöpfe der App bleiben meist erhalten.",
                    color = TextLo,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                ChoiceChips(TapMode.values().map { it.label to it }, tap) {
                    prefs.tapMode = it
                    Store.changed()
                }
            }
        }

        item {
            SettingCard("Ungesehenes aus der Leiste räumen") {
                Text(
                    "Wichtige Meldungen, die du nicht angesehen hast, wandern nach dieser Zeit in die Ablage.",
                    color = TextLo,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                ChoiceChips(listOf("Aus" to 0, "6 Std." to 6, "24 Std." to 24, "3 Tage" to 72), unseen) {
                    prefs.unseenHours = it
                    Store.changed()
                }
            }
        }

        item {
            SettingCard("Ablage aufbewahren") {
                Text("Danach wird alles endgültig gelöscht.", color = TextLo, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                ChoiceChips(listOf("1 Tag" to 1, "3 Tage" to 3, "7 Tage" to 7, "30 Tage" to 30), keep) {
                    prefs.keepDays = it
                    Store.changed()
                }
            }
        }

        item {
            SettingCard("Sammel-Benachrichtigung") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Gesammeltes als eine stille Meldung zeigen", Modifier.weight(1f))
                    Switch(
                        checked = digest,
                        onCheckedChange = {
                            prefs.digestOn = it
                            Notifier.updateDigest(ctx)
                            Store.changed()
                        }
                    )
                }
            }
        }

        item {
            SettingCard("Eigene Regeln") {
                Text(
                    "Regeln entstehen auch automatisch, wenn du bei einer Meldung auf „Spam“ oder „Wichtig“ tippst.",
                    color = TextLo,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                if (rules.isEmpty()) {
                    Text("Noch keine Regeln.", color = TextLo)
                }
                rules.forEach { r ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("„" + r.pattern + "“", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val scope = if (r.pkg.isEmpty()) "alle Apps" else AppInfo.label(ctx, r.pkg)
                            Text(
                                (if (r.action == Level.SPAM) "Spam" else "Immer wichtig") + " · " + scope,
                                color = if (r.action == Level.SPAM) Danger else Mint,
                                fontSize = 12.sp
                            )
                        }
                        TextButton(onClick = { Store.db.deleteRule(r.id); Store.changed() }) {
                            Icon(Icons.Default.Close, contentDescription = "Regel löschen", tint = TextLo)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Button(
                    onClick = { showRule = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) { Text("Regel hinzufügen") }
            }
        }

        item {
            Text(
                "Alles läuft nur auf deinem Handy. Es werden keine Nachrichten ins Internet gesendet.",
                color = TextLo,
                fontSize = 12.sp
            )
        }
    }

    if (showRule) RuleDialog { showRule = false }
}
