package com.ghost.notify

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.text.format.DateUtils
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

// ---------- Helfer ----------

fun isListenerEnabled(ctx: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

fun timeAgo(t: Long): String =
    DateUtils.getRelativeTimeSpanString(t, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()

fun launchSafe(ctx: Context, i: Intent) {
    try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Das lässt sich auf diesem Gerät nicht öffnen.", Toast.LENGTH_SHORT).show()
    }
}

fun openOriginal(ctx: Context, item: Item) {
    var done = false
    val pi = Store.intentFor(item.key)
    if (pi != null) {
        try {
            pi.send()
            done = true
        } catch (e: Exception) {
        }
    }
    if (!done) {
        val li = ctx.packageManager.getLaunchIntentForPackage(item.pkg)
        if (li != null) launchSafe(ctx, li)
        else Toast.makeText(ctx, "Die App lässt sich nicht öffnen.", Toast.LENGTH_SHORT).show()
    }
}

fun modeColor(m: AppMode): Color = when (m) {
    AppMode.ALWAYS -> Mint
    AppMode.AUTO -> Ghost
    AppMode.ONLY_IMPORTANT -> Accent
    AppMode.BUNDLE -> TextLo
    AppMode.BLOCK -> Danger
}

// ---------- Bausteine ----------

@Composable
fun AppIcon(pkg: String, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) { AppInfo.icon(ctx, pkg) }
    if (bmp != null) {
        Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(size).clip(RoundedCornerShape(10.dp)))
    } else {
        Box(
            Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(Surface2),
            contentAlignment = Alignment.Center
        ) {
            Icon(painter = painterResource(R.drawable.ic_stat_ghost), contentDescription = null, tint = TextLo, modifier = Modifier.size(size * 0.6f))
        }
    }
}

@Composable
fun GhostCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Surface1),
        border = BorderStroke(1.dp, Line)
    ) { content() }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = Ghost, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
}

@Composable
fun EmptyCard(text: String) {
    GhostCard {
        Text(text, color = TextLo, modifier = Modifier.padding(16.dp))
    }
}

@Composable
fun LevelTag(level: Level) {
    val (label, color) = when (level) {
        Level.IMPORTANT -> "Wichtig" to Mint
        Level.NORMAL -> "Normal" to TextLo
        Level.SPAM -> "Spam" to Danger
    }
    Text(label, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
fun ItemCard(item: Item, onClick: () -> Unit) {
    GhostCard(Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            AppIcon(item.pkg, 40.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    item.title.ifBlank { item.app },
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val preview = item.text.ifBlank { item.big }
                if (preview.isNotBlank()) {
                    Text(preview, color = TextLo, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(item.app + " · " + timeAgo(item.time), color = TextLo, fontSize = 12.sp)
                    Spacer(Modifier.width(8.dp))
                    LevelTag(item.level)
                }
            }
            if (!item.seen) {
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(10.dp).clip(CircleShape).background(Accent))
            }
        }
    }
}

// ---------- Detail mit Mini-Zusammenfassung ----------

@Composable
fun ItemDialog(item: Item, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val sum = remember(item.id) { Summarizer.summarize(item) }

    LaunchedEffect(item.id) {
        Store.db.setSeen(item.id, true)
        Notifier.cancelRepl(ctx, item.id)
        Store.changed()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(item.pkg, 36.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(sum.headline, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(item.app + " · " + timeAgo(item.time), color = TextLo, fontSize = 12.sp)
                }
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Kurz gesagt", color = Ghost, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                Text(sum.gist)
                if (sum.facts.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text("Erkannt", color = Ghost, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    sum.facts.forEach { Text("• $it", color = TextHi, fontSize = 14.sp) }
                }
                Spacer(Modifier.height(12.dp))
                Text(sum.note, color = TextLo, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { openOriginal(ctx, item); onDismiss() },
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        modifier = Modifier.weight(1f)
                    ) { Text("Original öffnen") }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            Actions.markSpam(ctx, item.id)
                            Toast.makeText(ctx, "Absender wird künftig als Spam sortiert", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Spam", maxLines = 1) }
                    OutlinedButton(
                        onClick = {
                            Actions.markImportant(ctx, item.id)
                            Toast.makeText(ctx, "Absender gilt künftig als wichtig", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Wichtig", maxLines = 1) }
                    OutlinedButton(
                        onClick = { Actions.delete(ctx, item.id); onDismiss() },
                        modifier = Modifier.weight(1f)
                    ) { Text("Löschen", maxLines = 1) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Schließen") } }
    )
}

// ---------- Hauptgerüst ----------

@Composable
fun Root(startTab: Int, openId: Long?, onOpenConsumed: () -> Unit) {
    var tab by remember { mutableIntStateOf(startTab) }
    var dialogItem by remember { mutableStateOf<Item?>(null) }

    LaunchedEffect(startTab) { tab = startTab }
    LaunchedEffect(openId) {
        if (openId != null) {
            dialogItem = Store.db.byId(openId)
            onOpenConsumed()
        }
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Surface1) {
                val tabs = listOf("Start", "Apps", "Ablage", "Mehr")
                val icons = listOf(Icons.Default.Home, Icons.Default.List, Icons.Default.Email, Icons.Default.Settings)
                tabs.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icons[i], contentDescription = null) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Ghost,
                            selectedTextColor = Ghost,
                            indicatorColor = Selected,
                            unselectedIconColor = TextLo,
                            unselectedTextColor = TextLo
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> HomeScreen(onOpenItem = { dialogItem = it }, goTab = { tab = it })
                1 -> AppsScreen()
                2 -> AblageScreen(onOpenItem = { dialogItem = it })
                else -> SettingsScreen()
            }
        }
    }

    dialogItem?.let { ItemDialog(it) { dialogItem = null } }
}

// ---------- Start ----------

@Composable
fun HomeScreen(onOpenItem: (Item) -> Unit, goTab: (Int) -> Unit) {
    val ctx = LocalContext.current
    val tick by Store.tick.collectAsState()

    val enabled = remember(tick) { isListenerEnabled(ctx) }
    val needsPost = remember(tick) {
        Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    }
    val shown = remember(tick) { Store.db.list(listOf(Disp.SHOWN), 30, onlyUnseen = true) }
    val bundled = remember(tick) { Store.db.list(listOf(Disp.BUNDLED), 200, onlyUnseen = true).size }
    val dayAgo = remember(tick) { System.currentTimeMillis() - 24L * 3600_000L }
    val nShown = remember(tick) { Store.db.count(listOf(Disp.SHOWN), dayAgo) }
    val nSorted = remember(tick) { Store.db.count(listOf(Disp.BUNDLED, Disp.FILTERED, Disp.EXPIRED), dayAgo) }
    val nSpam = remember(tick) { Store.db.count(listOf(Disp.SPAM), dayAgo) }

    val postLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { Store.changed() }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Surface2),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(painter = painterResource(R.drawable.ic_stat_ghost), contentDescription = null, tint = Ghost, modifier = Modifier.size(32.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Ghost Notify", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Ruhe in deiner Statusleiste", color = TextLo)
                }
            }
        }

        item {
            if (!enabled) {
                GhostCard {
                    Column(Modifier.padding(16.dp)) {
                        Text("Zugriff fehlt", color = Danger, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("Ghost Notify muss deine Benachrichtigungen lesen dürfen, um sie zu sortieren. Die Daten bleiben auf dem Handy.", color = TextLo)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Falls der Schalter ausgegraut ist: App-Info öffnen, oben rechts auf die drei Punkte tippen und „Eingeschränkte Einstellungen zulassen“ wählen. Danach nochmal versuchen.",
                            color = TextLo,
                            fontSize = 12.sp
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { launchSafe(ctx, Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
                            colors = ButtonDefaults.buttonColors(containerColor = Accent),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Zugriff erlauben") }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                launchSafe(
                                    ctx,
                                    Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("App-Info öffnen") }
                    }
                }
            } else {
                GhostCard {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(Mint))
                        Spacer(Modifier.width(10.dp))
                        Text("Aktiv. Ghost Notify sortiert mit.", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        if (needsPost) {
            item {
                GhostCard {
                    Column(Modifier.padding(16.dp)) {
                        Text("Ghost Notify braucht die Erlaubnis, selbst Benachrichtigungen zu zeigen. Sonst bleibt Wichtiges unsichtbar.", color = TextLo)
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = { postLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                            colors = ButtonDefaults.buttonColors(containerColor = Accent)
                        ) { Text("Erlauben") }
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Wichtig", nShown, Mint, Modifier.weight(1f))
                StatCard("Sortiert", nSorted, Ghost, Modifier.weight(1f))
                StatCard("Spam", nSpam, Danger, Modifier.weight(1f))
            }
        }
        item { Text("letzte 24 Stunden", color = TextLo, fontSize = 12.sp) }

        item { SectionTitle("WICHTIG & UNGESEHEN") }
        if (shown.isEmpty()) {
            item { EmptyCard("Alles ruhig. Nichts Wichtiges wartet auf dich.") }
        } else {
            items(shown, key = { it.id }) { ItemCard(it) { onOpenItem(it) } }
        }

        item { SectionTitle("GESAMMELT") }
        item {
            GhostCard(Modifier.clip(RoundedCornerShape(16.dp)).clickable { goTab(2) }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (bundled == 0) "Nichts gesammelt" else "$bundled gesammelte Benachrichtigungen", fontWeight = FontWeight.SemiBold)
                        Text("Tippen, um die Ablage zu öffnen", color = TextLo, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.Email, contentDescription = null, tint = Ghost)
                }
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: Int, color: Color, modifier: Modifier = Modifier) {
    GhostCard(modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(value.toString(), color = color, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(label, color = TextLo, fontSize = 12.sp)
        }
    }
}
