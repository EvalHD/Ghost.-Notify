package com.ghost.notify

import android.content.Context

object Actions {

    private fun sender(i: Item): String = i.title.ifBlank { i.text.take(25) }

    fun markSpam(ctx: Context, id: Long) {
        val i = Store.db.byId(id) ?: return
        val pat = sender(i)
        if (pat.isNotBlank()) Store.db.addRule(i.pkg, pat, Level.SPAM)
        Store.db.markSenderSpam(i.pkg, i.title, i.id)
        try { GhostListener.instance?.cancelNotification(i.key) } catch (e: Exception) { }
        Notifier.cancelRepl(ctx, id)
        Notifier.updateDigest(ctx)
        Store.changed()
    }

    fun markImportant(ctx: Context, id: Long) {
        val i = Store.db.byId(id) ?: return
        val pat = sender(i)
        if (pat.isNotBlank()) Store.db.addRule(i.pkg, pat, Level.IMPORTANT)
        Store.db.setSeen(id, true)
        Store.changed()
    }

    fun delete(ctx: Context, id: Long) {
        val i = Store.db.byId(id)
        Store.db.delete(id)
        if (i != null) {
            try { GhostListener.instance?.cancelNotification(i.key) } catch (e: Exception) { }
        }
        Notifier.cancelRepl(ctx, id)
        Notifier.updateDigest(ctx)
        Store.changed()
    }

    fun clearAblage(ctx: Context) {
        Store.db.deleteDisps(listOf(Disp.BUNDLED, Disp.FILTERED, Disp.EXPIRED, Disp.SPAM))
        Notifier.updateDigest(ctx)
        Store.changed()
    }
}
