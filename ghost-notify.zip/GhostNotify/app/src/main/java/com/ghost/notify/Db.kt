package com.ghost.notify

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Db(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "ghost.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE items (id INTEGER PRIMARY KEY AUTOINCREMENT, skey TEXT, pkg TEXT, app TEXT, " +
                "title TEXT, text TEXT, big TEXT, category TEXT, time INTEGER, level TEXT, disp TEXT, seen INTEGER DEFAULT 0)"
        )
        db.execSQL("CREATE INDEX idx_items_time ON items(time)")
        db.execSQL("CREATE TABLE rules (id INTEGER PRIMARY KEY AUTOINCREMENT, pkg TEXT, pattern TEXT, action TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    private val cols = arrayOf("id", "skey", "pkg", "app", "title", "text", "big", "category", "time", "level", "disp", "seen")

    private fun levelOf(s: String?): Level = try { if (s == null) Level.NORMAL else Level.valueOf(s) } catch (e: Exception) { Level.NORMAL }
    private fun dispOf(s: String?): Disp = try { if (s == null) Disp.FILTERED else Disp.valueOf(s) } catch (e: Exception) { Disp.FILTERED }

    private fun toItem(c: Cursor): Item = Item(
        id = c.getLong(0),
        key = c.getString(1) ?: "",
        pkg = c.getString(2) ?: "",
        app = c.getString(3) ?: "",
        title = c.getString(4) ?: "",
        text = c.getString(5) ?: "",
        big = c.getString(6) ?: "",
        category = c.getString(7) ?: "",
        time = c.getLong(8),
        level = levelOf(c.getString(9)),
        disp = dispOf(c.getString(10)),
        seen = c.getInt(11) == 1
    )

    private fun query(where: String?, args: Array<String>?, order: String, limit: Int): List<Item> {
        val out = ArrayList<Item>()
        readableDatabase.query("items", cols, where, args, null, null, order, limit.toString()).use { c ->
            while (c.moveToNext()) out.add(toItem(c))
        }
        return out
    }

    private fun inList(disps: List<Disp>): String = disps.joinToString(",") { "'" + it.name + "'" }

    private fun exec(sql: String, args: Array<Any>) {
        writableDatabase.execSQL(sql, args)
    }

    // ---------- Items ----------

    fun insert(i: Item): Long {
        val v = ContentValues()
        v.put("skey", i.key)
        v.put("pkg", i.pkg)
        v.put("app", i.app)
        v.put("title", i.title)
        v.put("text", i.text)
        v.put("big", i.big)
        v.put("category", i.category)
        v.put("time", i.time)
        v.put("level", i.level.name)
        v.put("disp", i.disp.name)
        v.put("seen", if (i.seen) 1 else 0)
        return writableDatabase.insert("items", null, v)
    }

    fun byId(id: Long): Item? = query("id = ?", arrayOf(id.toString()), "id", 1).firstOrNull()

    fun list(disps: List<Disp>, limit: Int = 300, onlyUnseen: Boolean = false): List<Item> {
        val where = "disp IN (" + inList(disps) + ")" + (if (onlyUnseen) " AND seen = 0" else "")
        return query(where, null, "time DESC", limit)
    }

    fun findRecent(pkg: String, title: String, text: String, since: Long): Item? =
        query("pkg = ? AND title = ? AND text = ? AND time > ?", arrayOf(pkg, title, text, since.toString()), "time DESC", 1).firstOrNull()

    fun unseenShownBefore(t: Long): List<Item> =
        query("disp = 'SHOWN' AND seen = 0 AND time < ?", arrayOf(t.toString()), "time", 200)

    fun count(disps: List<Disp>, since: Long): Int {
        val sql = "SELECT COUNT(*) FROM items WHERE disp IN (" + inList(disps) + ") AND time >= ?"
        readableDatabase.rawQuery(sql, arrayOf(since.toString())).use { c ->
            return if (c.moveToFirst()) c.getInt(0) else 0
        }
    }

    fun setDisp(id: Long, d: Disp) = exec("UPDATE items SET disp = ? WHERE id = ?", arrayOf(d.name, id))

    fun setSeen(id: Long, s: Boolean) = exec("UPDATE items SET seen = ? WHERE id = ?", arrayOf(if (s) 1 else 0, id))

    fun markSeenByKey(key: String) = exec("UPDATE items SET seen = 1 WHERE skey = ? AND disp = 'SHOWN'", arrayOf(key))

    fun markSeenDisps(disps: List<Disp>) = exec("UPDATE items SET seen = 1 WHERE disp IN (" + inList(disps) + ")", arrayOf())

    fun markSenderSpam(pkg: String, title: String, id: Long) {
        if (title.isNotBlank()) {
            exec("UPDATE items SET disp = 'SPAM', level = 'SPAM' WHERE pkg = ? AND title = ?", arrayOf(pkg, title))
        }
        exec("UPDATE items SET disp = 'SPAM', level = 'SPAM' WHERE id = ?", arrayOf(id))
    }

    fun delete(id: Long) = exec("DELETE FROM items WHERE id = ?", arrayOf(id))

    fun deleteDisps(disps: List<Disp>) = exec("DELETE FROM items WHERE disp IN (" + inList(disps) + ")", arrayOf())

    fun deleteOlder(disps: List<Disp>, before: Long) =
        exec("DELETE FROM items WHERE disp IN (" + inList(disps) + ") AND time < ?", arrayOf(before))

    fun knownPkgs(): List<String> {
        val out = ArrayList<String>()
        readableDatabase.rawQuery("SELECT pkg, MAX(time) AS t FROM items GROUP BY pkg ORDER BY t DESC", null).use { c ->
            while (c.moveToNext()) out.add(c.getString(0) ?: continue)
        }
        return out
    }

    // ---------- Regeln ----------

    fun rules(): List<Rule> {
        val out = ArrayList<Rule>()
        readableDatabase.query("rules", arrayOf("id", "pkg", "pattern", "action"), null, null, null, null, "id").use { c ->
            while (c.moveToNext()) {
                out.add(Rule(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", levelOf(c.getString(3))))
            }
        }
        return out
    }

    fun addRule(pkg: String, pattern: String, action: Level) {
        val exists = rules().any { it.pkg == pkg && it.pattern.equals(pattern, true) && it.action == action }
        if (exists) return
        val v = ContentValues()
        v.put("pkg", pkg)
        v.put("pattern", pattern)
        v.put("action", action.name)
        writableDatabase.insert("rules", null, v)
    }

    fun deleteRule(id: Long) = exec("DELETE FROM rules WHERE id = ?", arrayOf(id))
}
