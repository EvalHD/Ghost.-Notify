package com.ghost.notify

import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

object AppInfo {
    private val labels = HashMap<String, String>()
    private val icons = HashMap<String, ImageBitmap?>()

    fun label(ctx: Context, pkg: String): String {
        labels[pkg]?.let { return it }
        val l = try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        labels[pkg] = l
        return l
    }

    fun icon(ctx: Context, pkg: String): ImageBitmap? {
        if (icons.containsKey(pkg)) return icons[pkg]
        val b = try {
            ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (e: Exception) {
            null
        }
        icons[pkg] = b
        return b
    }

    /** Alle Apps mit Start-Symbol als Paar (Paketname, Name). */
    fun launchable(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first != ctx.packageName }
            .sortedBy { it.second.lowercase() }
    }

    private val mailPkgs = setOf(
        "com.google.android.gm", "com.google.android.gm.lite", "com.microsoft.office.outlook",
        "com.samsung.android.email.provider", "de.gmx.mobile.android.mail", "de.web.mobile.android.mail",
        "com.fsck.k9", "com.yahoo.mobile.client.android.mail", "ch.protonmail.android"
    )

    fun isMail(pkg: String, category: String): Boolean =
        category == "email" || pkg in mailPkgs || pkg.contains("mail", true)
}
