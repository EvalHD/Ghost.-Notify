package com.ghost.notify

import android.app.PendingIntent
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

/** Zentraler Zugriff auf Datenbank, Einstellungen und Änderungs-Signal für die Oberfläche. */
object Store {
    lateinit var db: Db
    lateinit var prefs: Prefs
    val tick = MutableStateFlow(0)

    private val intents = LinkedHashMap<String, PendingIntent>()
    @Volatile private var appCtx: Context? = null

    @Synchronized
    fun init(ctx: Context) {
        if (!::db.isInitialized) {
            val app = ctx.applicationContext
            appCtx = app
            db = Db(app)
            prefs = Prefs(app)
        }
    }

    fun changed() {
        tick.value = tick.value + 1
        val c = appCtx
        if (c != null) {
            try { Widget.update(c) } catch (e: Exception) { }
        }
    }

    fun cacheIntent(key: String, pi: PendingIntent) {
        synchronized(intents) {
            intents[key] = pi
            while (intents.size > 150) {
                val first = intents.keys.first()
                intents.remove(first)
            }
        }
    }

    fun intentFor(key: String): PendingIntent? = synchronized(intents) { intents[key] }
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("ghost_prefs", Context.MODE_PRIVATE)

    private val systemAlways = setOf(
        "android", "com.android.systemui", "com.android.phone", "com.android.server.telecom",
        "com.google.android.dialer", "com.samsung.android.dialer", "com.samsung.android.incallui",
        "com.samsung.android.app.telephonyui"
    )

    fun mode(pkg: String): AppMode {
        val s = sp.getString("mode_$pkg", null)
        if (s != null) {
            try { return AppMode.valueOf(s) } catch (e: Exception) { }
        }
        return if (pkg in systemAlways) AppMode.ALWAYS else AppMode.AUTO
    }

    fun setMode(pkg: String, m: AppMode) {
        sp.edit().putString("mode_$pkg", m.name).apply()
    }

    var tapMode: TapMode
        get() = try { TapMode.valueOf(sp.getString("tap_mode", TapMode.ALL.name) ?: "ALL") } catch (e: Exception) { TapMode.ALL }
        set(v) { sp.edit().putString("tap_mode", v.name).apply() }

    /** Stunden, nach denen ungesehene Wichtige aus der Leiste geräumt werden. 0 = aus. */
    var unseenHours: Int
        get() = sp.getInt("unseen_hours", 24)
        set(v) { sp.edit().putInt("unseen_hours", v).apply() }

    var keepDays: Int
        get() = sp.getInt("keep_days", 7)
        set(v) { sp.edit().putInt("keep_days", v).apply() }

    var paused: Boolean
        get() = sp.getBoolean("paused", false)
        set(v) { sp.edit().putBoolean("paused", v).apply() }

    var lastEvent: Long
        get() = sp.getLong("last_event", 0L)
        set(v) { sp.edit().putLong("last_event", v).apply() }

    var lastError: String
        get() = sp.getString("last_error", "") ?: ""
        set(v) { sp.edit().putString("last_error", v).apply() }

    var digestOn: Boolean
        get() = sp.getBoolean("digest_on", true)
        set(v) { sp.edit().putBoolean("digest_on", v).apply() }
}
