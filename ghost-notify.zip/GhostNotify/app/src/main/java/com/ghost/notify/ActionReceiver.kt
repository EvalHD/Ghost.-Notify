package com.ghost.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.init(context)
        val id = intent.getLongExtra("id", -1L)
        when (intent.action) {
            Notifier.ACT_SPAM -> if (id > 0) Actions.markSpam(context, id)
            Notifier.ACT_SEEN -> if (id > 0) Store.db.setSeen(id, true)
            Notifier.ACT_CLEAR -> {
                Store.db.deleteDisps(listOf(Disp.BUNDLED))
                Notifier.updateDigest(context)
            }
            Notifier.ACT_DIGEST_SEEN -> Store.db.markSeenDisps(listOf(Disp.BUNDLED))
            Notifier.ACT_CLEAR_ALL -> Actions.clearAblage(context)
            Notifier.ACT_TOGGLE_PAUSE -> Store.prefs.paused = !Store.prefs.paused
        }
        Store.changed()
    }
}
