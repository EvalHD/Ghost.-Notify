package com.ghost.notify

/** Lokale Mini-Zusammenfassung aus dem Text der Benachrichtigung. Nichts verlässt das Handy. */
object Summarizer {

    data class Summary(val headline: String, val gist: String, val facts: List<String>, val note: String)

    private val amount = Regex("(?:€\\s?\\d[\\d.]*(?:,\\d{1,2})?|\\d[\\d.]*(?:,\\d{1,2})?\\s?(?:€|EUR|Euro))", RegexOption.IGNORE_CASE)
    private val date = Regex("\\b\\d{1,2}\\.\\s?\\d{1,2}\\.(?:\\s?\\d{2,4})?")
    private val time = Regex("\\b(?:[01]?\\d|2[0-3]):[0-5]\\d\\b")
    private val code = Regex("\\b(?:code|tan|pin|otp|kennwort|passwort)\\b\\D{0,20}?(\\d{4,8})", RegexOption.IGNORE_CASE)
    private val link = Regex("https?://\\S+")
    private val splitter = Regex("(?<=[.!?])\\s+|\\n+")

    private fun clean(s: String): String = s.replace(Regex("[ \\t]+"), " ").replace(Regex("\\n{2,}"), "\n").trim()

    private fun cut(s: String, max: Int): String {
        if (s.length <= max) return s
        val t = s.take(max)
        val i = t.lastIndexOf(' ')
        return (if (i > max / 2) t.substring(0, i) else t) + "…"
    }

    fun summarize(item: Item): Summary {
        val body = clean(if (item.big.isNotBlank()) item.big else item.text)
        val who = item.title.ifBlank { item.app }
        val mail = AppInfo.isMail(item.pkg, item.category)

        val headline = when {
            mail -> "E-Mail von $who"
            item.category == "msg" -> "Nachricht von $who"
            item.title.isBlank() -> item.app
            else -> item.app + ": " + item.title
        }

        val sentences = body.split(splitter).map { it.trim() }.filter { it.isNotEmpty() }
        val gist = if (body.isBlank()) "Die Benachrichtigung enthält keinen Text." else cut(sentences.take(2).joinToString(" "), 220)

        val facts = ArrayList<String>()
        if (mail && item.text.isNotBlank() && item.text != body) facts.add("Betreff: " + cut(item.text, 90))
        val hay = item.title + " " + body
        amount.findAll(hay).map { it.value.trim() }.distinct().take(3).forEach { facts.add("Betrag: $it") }
        date.findAll(hay).map { it.value.trim() }.distinct().take(2).forEach { facts.add("Datum: $it") }
        time.findAll(hay).map { it.value.trim() }.distinct().take(2).forEach { facts.add("Uhrzeit: $it") }
        code.findAll(hay).mapNotNull { it.groupValues.getOrNull(1) }.distinct().take(2).forEach { facts.add("Code: $it") }
        val links = link.findAll(hay).count()
        if (links > 0) facts.add(if (links == 1) "Enthält einen Link" else "Enthält $links Links")
        when (item.level) {
            Level.SPAM -> facts.add("Wirkt wie Werbung oder Spam")
            Level.IMPORTANT -> facts.add("Als wichtig eingestuft")
            Level.NORMAL -> {}
        }

        val note = "Das ist nur die Vorschau aus der Benachrichtigung. Den ganzen Inhalt siehst du über „Original öffnen“."
        return Summary(headline, gist, facts, note)
    }
}
