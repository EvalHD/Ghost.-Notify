package com.ghost.notify

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Geister-Look: tiefes Nachtblau, Lavendel als Hauptfarbe, Mint als Akzent.
// Alle Farben stehen nur hier. Zum Anpassen an den Ghost-Browser einfach die Werte ändern.
val Bg = Color(0xFF0A0C12)
val Surface1 = Color(0xFF12151F)
val Surface2 = Color(0xFF1A1E2B)
val Line = Color(0xFF262B3D)
val Ghost = Color(0xFFB7A8FF)
val Accent = Color(0xFF7C6CFF)
val Mint = Color(0xFF5EEAD4)
val TextHi = Color(0xFFEDEBFF)
val TextLo = Color(0xFF9AA0B8)
val Danger = Color(0xFFFF6B8B)
val Selected = Color(0xFF2A2650)

@Composable
fun GhostTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color.White,
            primaryContainer = Selected,
            onPrimaryContainer = Ghost,
            secondary = Mint,
            onSecondary = Color(0xFF00201C),
            secondaryContainer = Selected,
            onSecondaryContainer = Ghost,
            background = Bg,
            onBackground = TextHi,
            surface = Surface1,
            onSurface = TextHi,
            surfaceVariant = Surface2,
            onSurfaceVariant = TextLo,
            error = Danger,
            outline = Line
        ),
        content = content
    )
}
