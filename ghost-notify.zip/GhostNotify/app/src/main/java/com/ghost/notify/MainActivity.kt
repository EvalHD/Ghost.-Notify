package com.ghost.notify

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {

    private var openId by mutableStateOf<Long?>(null)
    private var startTab by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        handle(intent)
        setContent {
            GhostTheme {
                Root(startTab = startTab, openId = openId, onOpenConsumed = { openId = null })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        Store.changed()
    }

    private fun handle(i: Intent?) {
        if (i == null) return
        val id = i.getLongExtra("open_id", -1L)
        if (id > 0) {
            openId = id
            startTab = 0
        }
        val t = i.getIntExtra("tab", -1)
        if (t >= 0) startTab = t
    }
}
