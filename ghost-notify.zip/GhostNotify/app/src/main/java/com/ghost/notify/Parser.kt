package com.ghost.notify

import android.app.Notification
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.service.notification.StatusBarNotification

object Parser {
    fun parse(ctx: Context, sbn: StatusBarNotification): Parsed {
        val n = sbn.notification
        val ex = n.extras
        val pkg = sbn.packageName

        val convTitle = ex.getCharSequence("android.conversationTitle")?.toString()?.trim().orEmpty()
        val title = (ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()).ifBlank { convTitle }
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val big = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()
        val lines = ex.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.joinToString("\n") { it.toString() }.orEmpty().trim()

        var msgs = ""
        try {
            @Suppress("DEPRECATION")
            val arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
            if (arr != null) {
                msgs = arr.mapNotNull { (it as? Bundle)?.getCharSequence("text")?.toString() }.joinToString("\n").trim()
            }
        } catch (e: Exception) {
        }

        val body = listOf(big, msgs, lines, text).maxByOrNull { it.length }.orEmpty()

        var group = convTitle.isNotBlank()
        if (Build.VERSION.SDK_INT >= 28 && ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION)) group = true

        return Parsed(
            pkg = pkg,
            app = AppInfo.label(ctx, pkg),
            title = title,
            text = text,
            body = body,
            category = n.category ?: "",
            isGroup = group,
            time = sbn.postTime,
            pending = n.contentIntent
        )
    }
}
